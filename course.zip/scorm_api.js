/* SCORM 2004 API wrapper — auto-injected by scorm_pack.py */
(function () {
  var _api = null;
  var _ready = false;

  function _findAPI(win) {
    var depth = 0;
    while (!win.API_1484_11 && win.parent && win.parent !== win) {
      if (++depth > 500) return null;
      win = win.parent;
    }
    return win.API_1484_11 || null;
  }

  function _getAPI() {
    var api = _findAPI(window);
    if (!api && window.opener) api = _findAPI(window.opener);
    return api;
  }

  var SCORM = {
    init: function () {
      _api = _getAPI();
      if (!_api) { console.warn("[SCORM] LMS API not found — running outside LMS"); return false; }
      var r = _api.Initialize("");
      _ready = (r === "true" || r === true);
      if (!_ready) console.warn("[SCORM] Initialize() returned false");
      return _ready;
    },

    set: function (key, value) {
      if (!_ready) return;
      _api.SetValue(key, String(value));
    },

    get: function (key) {
      if (!_ready) return "";
      return _api.GetValue(key);
    },

    commit: function () {
      if (!_ready) return;
      _api.Commit("");
    },

    finish: function () {
      if (!_ready) return;
      _api.Commit("");
      _api.Terminate("");
      _ready = false;
    },

    /* One-call shortcut — use on your "Завершить" button */
    complete: function () {
      this.set("cmi.completion_status", "completed");
      this.set("cmi.success_status",    "passed");
      this.set("cmi.score.min",         "0");
      this.set("cmi.score.max",         "100");
      this.set("cmi.score.raw",         "100");
      this.set("cmi.score.scaled",      "1");
      this.commit();
    }
  };

  window.addEventListener("load",         function () { SCORM.init(); });
  window.addEventListener("beforeunload", function () { SCORM.finish(); });

  window.SCORM = SCORM;
})();