/* SCORM 1.2 API wrapper — auto-injected by scorm_pack.py */
(function () {
  var _api = null;
  var _ready = false;
  var _finished = false;
  var _startedAt = new Date().getTime();

  function _findAPI(win) {
    var depth = 0;
    while (!win.API && win.parent && win.parent !== win) {
      if (++depth > 7) return null;
      win = win.parent;
    }
    return win.API || null;
  }

  function _getAPI() {
    var api = _findAPI(window);
    if (!api && window.opener) api = _findAPI(window.opener);
    return api;
  }

  function _sessionTime() {
    var hundredths = Math.max(0, Math.floor((new Date().getTime() - _startedAt) / 10));
    var hours = Math.floor(hundredths / 360000);
    hundredths -= hours * 360000;
    var minutes = Math.floor(hundredths / 6000);
    hundredths -= minutes * 6000;
    var seconds = Math.floor(hundredths / 100);
    var fraction = hundredths % 100;
    function pad(value, width) {
      var result = String(value);
      while (result.length < width) result = "0" + result;
      return result;
    }
    return pad(hours, 4) + ":" + pad(minutes, 2) + ":" + pad(seconds, 2) + "." + pad(fraction, 2);
  }

  var SCORM = {
    init: function () {
      _api = _getAPI();
      if (!_api) { console.warn("[SCORM] LMS API not found — running outside LMS"); return false; }
      var r = _api.LMSInitialize("");
      _ready = (r === "true" || r === true);
      _finished = false;
      _startedAt = new Date().getTime();
      if (!_ready) console.warn("[SCORM] LMSInitialize() returned false");
      return _ready;
    },

    set: function (key, value) {
      if (!_ready) return;
      _api.LMSSetValue(key, String(value));
    },

    get: function (key) {
      if (!_ready) return "";
      return _api.LMSGetValue(key);
    },

    commit: function () {
      if (!_ready) return;
      _api.LMSCommit("");
    },

    finish: function (exitValue) {
      if (!_ready || _finished) return;
      _finished = true;
      this.set("cmi.core.session_time", _sessionTime());
      this.set("cmi.core.exit", exitValue || "");
      _api.LMSCommit("");
      _api.LMSFinish("");
      _ready = false;
    },

    /* One-call shortcut — use on your "Завершить" button */
    complete: function () {
      this.set("cmi.core.score.min",     "0");
      this.set("cmi.core.score.max",     "100");
      this.set("cmi.core.score.raw",     "100");
      this.set("cmi.core.lesson_status", "completed");
      this.commit();
      this.finish();
    }
  };

  window.addEventListener("load",         function () { SCORM.init(); });
  function suspendUnfinishedSession() {
    if (!_ready || _finished) return;
    SCORM.finish("suspend");
  }
  window.addEventListener("pagehide", suspendUnfinishedSession);
  window.addEventListener("beforeunload", suspendUnfinishedSession);

  window.SCORM = SCORM;
})();